import sys
from datetime import datetime, timedelta
from airflow import DAG
from airflow.operators.python import PythonOperator
import pendulum
from airflow.utils.email import send_email

sys.path.append('/opt/airflow/producers')

from league_producer import run 

# Failure callback that sends email
def send_failure_email(context):
    try:
        ti = context['ti']
        dag_run = context.get('dag_run')
        execution_time = dag_run.logical_date if dag_run else 'N/A'

        send_email(
            to=['shinetym@gmail.com'],
            subject=f"DAG {ti.dag_id} - Task {ti.task_id} FAILED",
            html_content=f"""
            Task: {ti.task_id} <br>
            DAG: {ti.dag_id} <br>
            Execution Time: {execution_time} <br>
            Exception: {context.get('exception')} <br>
            """
        )
        print("Failure email sent successfully")
    except Exception as e:
        print(f"Failed to send failure email: {e}")

egypt_tz = pendulum.timezone("Africa/Cairo")

default_args = {
    'owner': 'ahmed elsayad',
    'depends_on_past': False,
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 1,
    'retry_delay': timedelta(minutes=1),
    'start_date': datetime(2025, 8, 8, tzinfo=egypt_tz),
    'on_failure_callback': send_failure_email ,

}

with DAG(
    dag_id="league_proucer_daily_dag",
    default_args=default_args,
    description='DAG to run league producer once daily at midnight Egypt time',
    catchup=False,
    schedule='0 0 * * *',  # every day at midnight
    tags=['soccer.league']
) as dag:

    task_run_league = PythonOperator(
        task_id='run_league_producer_once',
        python_callable=run,
    )

    task_run_league
